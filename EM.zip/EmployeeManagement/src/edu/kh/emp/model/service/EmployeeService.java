package edu.kh.emp.model.service;

public class EmployeeService {

}
