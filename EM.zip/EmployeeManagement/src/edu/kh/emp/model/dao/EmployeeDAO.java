package edu.kh.emp.model.dao;

public class EmployeeDAO {

}
